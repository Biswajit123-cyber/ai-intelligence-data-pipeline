import asyncio
import json
import random
from dataclasses import dataclass
from typing import Any, Protocol
from .chunker import semantic_chunks

class Provider(Protocol):
    name: str
    async def extract(self, text: str, schema: dict[str, Any]) -> dict[str, Any]: ...

@dataclass
class ExtractionResult:
    provider: str
    data: dict[str, Any]

class LLMOrchestrator:
    def __init__(self, providers: list[Provider], max_retries: int = 3):
        self.providers = providers
        self.max_retries = max_retries

    async def extract(self, text: str, schema: dict[str, Any]) -> ExtractionResult:
        chunks = semantic_chunks(text, max_chars=12000)

        last_error = None
        for provider in self.providers:
            for attempt in range(self.max_retries):
                try:
                    # A production implementation can aggregate chunk-level results.
                    # We keep the prompt payload bounded and validate JSON after return.
                    payload = chunks[0] if chunks else ""
                    data = await provider.extract(payload, schema)
                    if not isinstance(data, dict):
                        raise ValueError("Provider returned non-object JSON")
                    return ExtractionResult(provider=provider.name, data=data)
                except Exception as exc:
                    last_error = exc
                    if attempt < self.max_retries - 1:
                        await asyncio.sleep(min(30, (2 ** attempt) + random.random()))
                    else:
                        break

        raise RuntimeError(f"All LLM providers failed: {last_error}")

# Provider adapters are intentionally isolated so API SDK changes do not affect
# the crawler, resolver, storage, or schemas.
class GeminiProvider:
    name = "gemini"

    def __init__(self, api_key: str, model: str = "gemini-3.7-flash"):
        self.api_key, self.model = api_key, model

    async def extract(self, text: str, schema: dict[str, Any]) -> dict[str, Any]:
        if not self.api_key:
            raise RuntimeError("GEMINI_API_KEY is not configured")
        from google import genai
        client = genai.Client(api_key=self.api_key)
        prompt = (
            "Extract only facts explicitly supported by the source text. "
            "Return valid JSON matching this schema exactly. Unknown values must be null.\\n"
            f"SCHEMA:\\n{json.dumps(schema)}\\nSOURCE:\\n{text}"
        )
        response = await asyncio.to_thread(
            client.models.generate_content,
            model=self.model,
            contents=prompt,
            config={"response_mime_type": "application/json"},
        )
        return json.loads(response.text)

class GroqProvider:
    name = "groq"

    def __init__(self, api_key: str, model: str = "llama-3.3-70b-versatile"):
        self.api_key, self.model = api_key, model

    async def extract(self, text: str, schema: dict[str, Any]) -> dict[str, Any]:
        if not self.api_key:
            raise RuntimeError("GROQ_API_KEY is not configured")
        from groq import Groq
        client = Groq(api_key=self.api_key)
        prompt = (
            "Return JSON only. Extract only facts supported by the source. "
            f"Schema: {json.dumps(schema)}\\nSource: {text}"
        )
        response = await asyncio.to_thread(
            client.chat.completions.create,
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)

class DeepSeekProvider:
    name = "deepseek"

    def __init__(self, api_key: str, model: str = "deepseek-chat"):
        self.api_key, self.model = api_key, model

    async def extract(self, text: str, schema: dict[str, Any]) -> dict[str, Any]:
        if not self.api_key:
            raise RuntimeError("DEEPSEEK_API_KEY is not configured")
        from openai import OpenAI
        client = OpenAI(api_key=self.api_key, base_url="https://api.deepseek.com")
        prompt = (
            "Return JSON only. Extract only facts supported by the source. "
            f"Schema: {json.dumps(schema)}\\nSource: {text}"
        )
        response = await asyncio.to_thread(
            client.chat.completions.create,
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)
